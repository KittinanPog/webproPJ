<template>
  <div>
    <section class="hero">
      <div class="hero-body ml-5">
        <p class="title">Create a New Blog</p>
      </div>
    </section>
    <section class="container">
      <div class="content">
        <div class="field">
          <label class="label">Title</label>
          <input
            class="input"
            type="text"
            name="title"
            placeholder="Blog title"
            v-model="title"
          />
          <p class="help is-danger">*Required</p>
        </div>
        <section>
          <div class="content">
        <div class="field">
          <label class="label">Item</label>
          <input
            class="input"
            type="text"
            name="item"
            placeholder="Item Name"
            v-model="item"
          />
          <p class="help is-danger">*Required</p>
        </div>
        <div class="field">
          <label class="label">Item Info</label>
          <input
            class="input"
            type="text"
            name="item_desc"
            placeholder="Item Info"
            v-model="item_desc"
          />
          <p class="help is-danger">*Required</p>
        </div>
        <div class="file">
          <label class="file-label">
            <input
              class="file-input"
              type="file"
              name="item_image"
              id="file"
              ref="file"
              @change="handleFileUpload()"
            />
            <span class="file-cta">
              <span class="file-icon">
                <i class="fas fa-upload"></i>
              </span>
              <span class="file-label"> Choose an image… </span>
            </span>
          </label>
        </div>
        </div>
        </section>
        <div class="field">
          <label class="label">Description</label>
          <div class="control">
            <textarea
              class="textarea"
              placeholder="Textarea"
              name="description"
              v-model="description"
            ></textarea>
            <p class="help is-danger">*Required</p>
          </div>
        </div>
        
        
        <div class="field is-grouped mt-3">
          <div class="control">
            <input
              type="button"
              class="button is-link"
              value="submit"
              @click="submit()"
            />
          </div>
          <div class="control">
            <input
              type="button"
              class="button is-link"
              value="Back to home"
              @click="bth()"
            />
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import axios from "@/plugins/axios";

export default {
  data() {
    return {
      title: "",
      description: "",
      item: "",
      item_desc: "",
      file: null,
    };
  },
  methods: {
    handleFileUpload() {
      this.file = this.$refs.file.files[0];
    },
    submit() {
      var formData = new FormData();
      formData.append("item_image", this.file);
      formData.append("title", this.title);
      formData.append("item_name", this.item);
      formData.append("item_desc", this.item_desc);
      formData.append("description", this.description);
      
      axios
        
        .post("http://localhost:3000/blogs", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
          
        })
        
        .then((response) => {
          console.log(response);
          this.$router.push({ name: "Home" }); // Success! -> redirect to home page
        })
        .catch((error) => {
          console.log(error.message);
        });
        
    },
    bth() {
        
          this.$router.push({ name: "Home" }); // Success! -> redirect to home page
        
    },
  },
};
</script>
