<template>
  <div class="container is-widescreen">
    <section class="hero">
      <div class="hero-body">
        <p class="title">{{ blog.title }}</p>
      </div>
    </section>
    <section class="section" id="app">
      <div class="content">
        <div class="card has-background-light">
          <div class="card-image pt-5">
            <div class="columns">
              <div class="column">
                <figure class="image">
                  <img
                    :src="'http://localhost:3000/' + blog.image"
                    alt="Placeholder image"
                  />
                </figure>
              </div>
            </div>
          </div>
          <div class="card-content">
            <div class="content">{{ blog.description }}</div>
            <!-- <div class="container">
              <p class="subtitle">Comments</p>
              <div class="box" v-for="comment of comments" :key="comment.id">
                <article class="media">
                  <div class="media-left">
                    <figure class="image is-64x64">
                      <img
                        :src="'http://localhost:3000/' + comment.file_path"
                        alt="Image"
                      />
                    </figure>
                  </div>
                  <div class="media-content">
                    <div class="content">
                      <p>{{ comment.comment }}</p>
                      <p class="is-size-7">{{ comment.comment_date }}</p>
                    </div>
                    <nav class="level is-mobile">
                      <div class="level-left">
                        <a class="level-item" aria-label="like">
                          <span class="icon is-small">
                            <i class="fas fa-heart" aria-hidden="true"></i>
                          </span>
                        </a>
                      </div>
                    </nav>
                  </div>
                </article>
              </div>
              <div class="field">
                <label class="label">Add Comment</label>
                <div class="control">
                  <textarea
                    class="textarea"
                    name="comment"
                    placeholder="Add Comment Here"
                    v-model="text"
                  ></textarea>
                </div>
              </div>
              <input
                type="file"
                name="blog_image"
                ref="file"
                @change="handleFileUpload()"
              />
              <input
                type="submit"
                class="button is-primary"
                value="submit"
                @click="submit()"
              />
            </div> -->
          </div>
          <footer class="card-footer">
            <a class="card-footer-item" href="/">กลับหน้าหลัก</a>
          </footer>
        </div>
      </div>
    </section>
  </div>
</template>
<script>
import axios from "axios";

export default {
  data() {
    return {
      blog: null,
      comments: null,
      file: null,
    };
  },
  created() {
    axios
      .get("http://localhost:3000/blogs/" + this.$route.params.id)
      .then((response) => {
        this.blog = response.data.blog;
        // this.comments = response.data.comments;
        console.log(this.blog);
        // console.log(this.comments);
      })
      .catch((err) => {
        console.log(err.message);
      });
  },
  // methods: {
  //   handleFileUpload() {
  //     this.file = this.$refs.file.files[0];
  //   },
  //   submit() {
  //     var formData = new FormData();
  //     formData.append("blog_image", this.file);
  //     formData.append("comment", this.text);
  //     axios
  //       .post("http://localhost:3000/" + this.$route.params.id + "/comments", formData, {
  //         headers: {
  //           "Content-Type": "multipart/form-data",
  //         },
  //       })
  //       .then((response) => {
  //         console.log(response);
  //       })
  //       .catch((error) => {
  //         console.log(error.message);
  //       });
  //   },
  // },
};
</script>
<style scoped></style>
