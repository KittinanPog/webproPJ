<template>
  <div class="container is-widescreen">
    
    <section class="section" id="app">
      <div class="content">
        <div class="card">
          <div class="card-content">
            <div class="content"></div>
          </div>
          <div class="card-content">
            <div class="content"></div>
          </div>
          <footer class="card-footer">
            <a class="card-footer-item" href="/">กลับหน้าหลัก</a>
          </footer>
        </div>
      </div>
    </section>
  </div>
</template>
<script>
</script>
<style scoped></style>
