<template>
  <div class="container is-widescreen">
    <section class="hero">
      <div class="hero-body">
        <p class="title">My Stories</p>
      </div>
    </section>
    <section class="section" id="app">
      <div class="content">
        <div class="columns">
          <div class="column is-2">
            <input class="button" type="submit" value="Search" />
          </div>
          <div class="column is-2">
            <router-link to="/blog/create">
              <input class="button" type="button" value="Create New Blog" />
            </router-link>
          </div>
        </div>
      </div>
      <div class="content">
        <div class="columns is-multiline">
          <div class="column is-3" v-for="blog in blogs" :key="blog.id">
            <div class="card">
              <div class="card-image pt-5">
                <figure class="image">
                  <img
                    :src="'http://localhost:3000/' + blog.image"
                    alt="Placeholder image"
                  />
                </figure>
              </div>
              <div class="card-content">
                <div class="title">{{ blog.title }}</div>
                <div class="content">
                  <span v-if="blog.description.length > 200">
                    {{ blog.description.substring(0, 197) + "..." }}
                  </span>
                  <span v-else>
                    {{ blog.description }}
                  </span>
                </div>
              </div>
              <footer class="card-footer">
                <router-link :to="'/detail/' + blog.id">
                <a class="card-footer-item">Read more...</a>
                </router-link>
                
              </footer>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      blogs: null,
    };
  },

  created() {
    axios
      .get("http://localhost:3000/")
      .then((response) => {
        this.blogs = response.data;
        console.log(this.blogs);
      })
      .catch((err) => {
        console.log(err.message);
      });
  },

  methods: {
    addlike(blog) {
      axios
        .post("http://localhost:3000/blogs/addlike/" + blog.id)
        .then((response) => {
          blog.like++;
          console.log(response);
        })
        .catch((error) => {
          console.log(error.message);
        });
    },
  },
};
</script>

<style scoped></style>
