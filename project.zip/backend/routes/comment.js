const express = require("express");
const path = require("path");
const router = express.Router()
const multer = require("multer");
const pool = require("../config");

var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./static/uploads"); // path to save file
  },
  filename: function (req, file, callback) {
    // set file name
    callback(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});

const upload = multer({ storage: storage });

// Get comment
router.get("/:blogId/comments", function (req, res, next) {});

// Create new comment
router.post(
  "/:blogId/comments", upload.single('upload_image'),
  async function (req, res, next) {

    const content = req.body.content;
    


    const conn = await pool.getConnection();
    await conn.beginTransaction();

    try {
      let results = await conn.query(
        "INSERT INTO comments(blog_id,content,comment_date) VALUES(?,?,CURRENT_TIMESTAMP)",
        [req.params.blogId, content]
      );

      await conn.commit();
    
      res.redirect("/blogs/" + req.params.blogId);
    } catch (err) {
      await conn.rollback();
      next(err);
    } finally {
      console.log("finally");
      conn.release();
    }
  }
);

// Update comment
router.put("/comments/:commentId", function (req, res, next) {
  return;
});

// Delete comment
router.delete("/comments/:commentId", async function (req, res, next) {
  try {
    const [rows, fields] = await pool.query(
      "DELETE FROM comments WHERE id =?",
      [req.params.commentId]
    );

    return res.json({
      message: "Comment ID" + req.params.commentId + "is deleted.",
    });
  } catch (err) {
    return next(err);
  }
});

// Delete comment
router.put("/comments/addlike/:commentId", async function (req, res, next) {
  try {
    const [rows, fields] = await pool.query(
      "SELECT * FROM comments WHERE id=?",
      [req.params.commentId]
    );
    console.log("Selected blogs =", rows);
    rows[0].like++;
    console.log("Like num =", rows[0].like);
    const [rows2, fields2] = await pool.query(
      "UPDATE comments SET comments.like = ? WHERE comments.id=?",
      [rows[0].like, req.params.commentId]
    );

    return res.json({
      blogId: rows[0].blog_id,
      commentId: rows[0].id,
      likeNum: rows[0].like,
    });
  } catch (err) {
    return next(err);
  }
});

exports.router = router;