const express = require("express");
const path = require("path");
const router = express.Router()
const multer = require("multer");
const pool = require("../config");
const { isLoggedIn } = require("../middlewares");


var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./static/uploads"); // path to save file
  },
  filename: function (req, file, callback) {
    // set file name
    callback(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});

const upload = multer({ storage: storage });

//create chat
router.post("/chats", upload.single('chat_image'), isLoggedIn, async function (req, res, next) {
    
      const chat_by = "";
      const chat_to = "";
      const message = req.body.message;
      const status = "on_going";
      
      const conn = await pool.getConnection()
      // Begin transaction
      await conn.beginTransaction();
  
      try {
        
        let chat = await conn.query(
          "INSERT INTO chats(chat_by_id, chat_to_id, message, chat_status, message_time_stamp) VALUES(?, ?, ?, ?, CURRENT_TIMESTAMP);",
          [chat_by, chat_to, message, status]
        )
        const chatId = chat[0].insertId;
        
        
        await conn.commit()
        res.json("success!")
      } catch (err) {
        await conn.rollback();
        res.status(400).json(err)
      } finally {
        console.log('finally')
        conn.release();
      }
      
  
      
      
  });
  
  router.get("/blogs/:id",isLoggedIn, function (req, res, next) {
    const promise1 = pool.query("SELECT * FROM blogs JOIN items on blogs.id=items.blog_id where id=?", [req.params.id]);
    const promise2 = pool.query("SELECT * FROM comments where comments.blog_id=?", [req.params.id]);
    
  
    Promise.all([promise1,
      promise2
    ])
      .then((results) => {
        const blogs = results[0];
        const comments = results[1];
        // const images = results[2];
        res.json({
          blog: blogs[0][0],
          // images: images[0],
          comments: comments[0],
          error: null,
        });
        
      })
      .catch((err) => {
        return next(err);
      });
  });

// Get comment
router.get("/:blogId/comments", function (req, res, next) {

});

// Create new comment
router.post(
  "/:blogId/comments", upload.single('comment_image'),isLoggedIn,
  async function (req, res, next) {

    const content = req.body.content;
    
    const conn = await pool.getConnection();
    await conn.beginTransaction();

    try {
      let results = await conn.query(
        "INSERT INTO comments(blog_id,content, image, comment_by_id,comment_date) VALUES(?,?,?,?,CURRENT_TIMESTAMP)",
        [req.params.blogId, content, req.user.picture, req.user.id]
      );

      await conn.commit();
    
      res.redirect("/blogs/" + req.params.blogId);
    } catch (err) {
      await conn.rollback();
      next(err);
    } finally {
      console.log("finally");
      conn.release();
    }
  }
);

// Update comment
router.put('/comments/:commentId', upload.single('comment_image'),isLoggedIn,
  async function (req, res, next) {
  try {
      const [rows1, fields1] = await pool.query(
          'UPDATE comments SET content=? WHERE comment_id=?', [req.body.content, req.params.commentId]
      )
      console.log(rows1)
      res.json({ comment: req.body.content })
  } catch (error) {
      res.status(500).json(error)
  }
});

// Delete comment
router.delete("/comments/:commentId",isLoggedIn,
 async function (req, res, next) {
  try {
    const [rows, fields] = await pool.query(
      "DELETE FROM comments WHERE id =?",
      [req.params.commentId]
    );

    return res.json({
      message: "Comment ID" + req.params.commentId + "is deleted.",
    });
  } catch (err) {
    return next(err);
  }
});

// Delete comment
router.put("/comments/addlike/:commentId",isLoggedIn,commentOwner, async function (req, res, next) {
  try {
    const [rows, fields] = await pool.query(
      "SELECT * FROM comments WHERE id=?",
      [req.params.commentId]
    );
    console.log("Selected blogs =", rows);
    rows[0].like++;
    console.log("Like num =", rows[0].like);
    const [rows2, fields2] = await pool.query(
      "UPDATE comments SET comments.like = ? WHERE comments.id=?",
      [rows[0].like, req.params.commentId]
    );

    return res.json({
      blogId: rows[0].blog_id,
      commentId: rows[0].id,
      likeNum: rows[0].like,
    });
  } catch (err) {
    return next(err);
  }
});

exports.router = router;