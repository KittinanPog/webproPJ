<template>
  <div>
    <section class="hero">
      <div class="hero-body ml-5">
        <p class="title has-text-centered">Create a New Blog</p>
      </div>
    </section>
    <section class="container">
      <div class="content">
        <div class="field">
          <label class="label">Title</label>
          <input
            class="input"
            type="text"
            name="title"
            placeholder="Blog title"
            v-model="$v.title.$model" :class="{'is-danger': $v.title.$error}"
          />
          <template v-if="$v.title.$error">
            <p class="help is-danger" v-if="!$v.title.required">This field is required</p>
        </template>
        </div>
        <section>
          <div class="content">
        <div class="field">
          <label class="label">Item Name</label>
          <input
            class="input"
            type="text"
            name="item"
            placeholder="Item Name"
            v-model="$v.item.$model" :class="{'is-danger': $v.item.$error}"
          />
          <template v-if="$v.item.$error">
            <p class="help is-danger" v-if="!$v.item.required">This field is required</p>
        </template>
        </div>
        <div class="field">
          <label class="label">Item Description</label>
          <input
            class="input"
            type="text"
            name="item_desc"
            placeholder="Item Info"
            v-model="$v.item_desc.$model" :class="{'is-danger': $v.item_desc.$error}"
          />
          <template v-if="$v.item_desc.$error">
            <p class="help is-danger" v-if="!$v.item_desc.required">This field is required</p>
          </template>
        </div>
        <div class="file" style="padding:8px 0px">
          <label class="file-label">
            <input
              class="file-input"
              type="file"
              name="item_image"
              id="file"
              ref="file"
              @change="handleFileUpload()"
            />
            <span class="file-cta">
              <span class="file-icon">
                <i class="fas fa-upload"></i>
              </span>
              <span class="file-label"> Choose an image… </span>
            </span>
          </label>
        </div>
        </div>
        </section>
        <div class="field">
          <label class="label">Description</label>
          <div class="control">
            <textarea
              class="textarea"
              placeholder="Textarea"
              name="description"
              v-model="$v.description.$model" :class="{'is-danger': $v.description.$error}"
            ></textarea>
            <template v-if="$v.description.$error">
            <p class="help is-danger" v-if="!$v.description.required">This field is required</p>
          </template>
          </div>
        </div>
        
        
        <div class="field is-grouped mt-3">
          <div class="control">
            <input
              type="button"
              class="button is-link"
              value="Submit"
              @click="submit()"
            />
          </div>
          <div class="control">
            <input
              type="button"
              class="button is-warning"
              value="Back to home"
              @click="bth()"
            />
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import axios from "@/plugins/axios";
import { required} from 'vuelidate/lib/validators'

export default {
  data() {
    return {
      title: "",
      description: "",
      item: "",
      item_desc: "",
      file: null,
      error: null,
    };
  },
  validations: {
    title: {
      required: required,
    },
    item: {
      required: required,
    },
    item_desc: {
      required: required,
    },
    description: {
      required: required,
    }
  },
  methods: {
    handleFileUpload() {
      this.file = this.$refs.file.files[0];
    },
    submit() {
      var formData = new FormData();
      formData.append("item_image", this.file);
      formData.append("title", this.title);
      formData.append("item_name", this.item);
      formData.append("item_desc", this.item_desc);
      formData.append("description", this.description);
      
      axios
        
        .post("http://localhost:3000/blogs", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
          
        })
        
        .then((response) => {
          console.log(response);
          this.$router.push({ name: "Home" }); // Success! -> redirect to home page
        })
        .catch((error) => {
          console.log(error.message);
        });
        
    },
    bth() {
          this.$router.push({ name: "Home" }); // Success! -> redirect to home page
    },
  },
};
</script>
