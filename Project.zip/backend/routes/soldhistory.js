const express = require("express")
const path = require("path")
const pool = require("../config")
const { isLoggedIn } = require("../middlewares");
router = express.Router();
router.get("/history",isLoggedIn, function (req, res, next) {
    // const promise1 = pool.query("SELECT item_id, item_name, item_desc, status FROM items JOIN users on items.id=users.id where items.status=?", ['Sell']);
    const promise1 = pool.query("SELECT * FROM items Join users on items.own_by_id=users.id where seller_id=? and status=?", [req.user.id, 'Sold']);
    
  
    Promise.all([promise1
    ])
      .then((results) => {
        const historys = results[0];
        // const images = results[2];
        res.json({
          history: historys[0],
          // images: images[0],
          error: null,
        });
        
      })
      .catch((err) => {
        return next(err);
      });
  });

exports.router = router;
